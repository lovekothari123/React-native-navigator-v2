import { AppRegistry } from 'react-native';
import App from './app/index';

AppRegistry.registerComponent('ReactNavigationExampleVersion2', () => App);
