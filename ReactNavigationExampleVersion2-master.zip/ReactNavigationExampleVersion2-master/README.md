## React Navigation Version 2 Example

The most Common part of any App is navigation. React navigation is one of the popular library for the Navigation in React Navigation.
<br>
This example include the integration of Tabs Navigation inside Drawer Navigation inside Stack Navigation.

## Setup

1. Download the Repository
<br>
2. npm install
<br>
3. react-native start
<br>
4. react-native run ios or react-native run android


