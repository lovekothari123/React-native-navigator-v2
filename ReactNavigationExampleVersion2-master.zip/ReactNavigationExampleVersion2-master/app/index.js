import React,{Component} from 'react';
import Navigator from './modules/setup/routes';

export default class App extends Component{
    render(){
        return(
            <Navigator/>
        )
    }
}